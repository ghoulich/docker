为了方便大家开发，统一了所有SQL，请先后执行：

- 0-init_table.sql        create db,tables
- 1-init_data.sql         create data
- 201512/20151225.sql     patch
- 20160701/20160701.sql   patch
